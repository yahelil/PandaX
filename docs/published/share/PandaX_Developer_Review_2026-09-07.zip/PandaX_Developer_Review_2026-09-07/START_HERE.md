# PandaX developer review - 7 September 2026

Open **index.html** for an offline, clickable overview. Start with **pdf/PandaX_Developer_Validation_Report.pdf** for observed results; use **pdf/PandaX_Independent_Expected_Results.pdf** as the independent online-source answer key.

- 14 inputs completed, all 14 seals verified; four built-in comparisons passed.
- 76 named checks: 35 hits, seven misses, 34 correct absences.
- All 407 reported component/CVE rows are included. Extra findings are ungraded, not assumed false positives.
- The four missed CVEs occur across seven release/CVE checks. Inventory was correct; exact OSV identifiers yielded no candidates and the native supplement lacks those CVE rules.
- Tested the pulled local dashboard at d7f7890. A separate hosted deployment was not verified. No exploit/runtime testing was performed. No scanner fix was applied during this validation or diagnosis.

## Where to look

| Location | Contents |
|---|---|
| reports/PandaX_Root_Cause_Report.md | Cause of every miss, source locations, API probes, feed conflict and developer priorities |
| reports/PandaX_Comparison_Report.md | Overall comparison, all inputs, triage discrepancies and test results |
| reports/all-reference-checks.csv | All 76 named expectations, observations, fix versions, applicability and source URLs |
| reports/missed-findings.csv | Seven misses, ready for issue tracking |
| reports/all-reported-findings.csv | All 407 reported rows, with named-hit/ungraded labels |
| cases/ | Per-input HTML, Markdown, CSV and JSON results |
| evidence/api/ | Original saved summaries, events and verify responses for 14 scans and four comparisons |
| evidence/bundles/ | Original output files for 14 scans, four comparisons and eight comparison child scans (26 bundles) |
| reports/root-cause-evidence/ | Timestamped fresh OSV diagnostic requests/responses; separate from original scan results |
| reference/ | Frozen public-source baseline and source register |
| reproduction/ | Exact tested source, fixtures and runner/probe/build scripts |

## Evidence scope and integrity

Output files are copied byte-for-byte, including original manifest/signature/public key, SBOM, findings, VEX, ledger and automatic PoC PDFs. Vendor source archives and extracted trees are omitted to keep this package shareable; their hashes remain in the original manifests and evidence/export-map.json lists omissions. Private signing keys, credentials, caches and Git metadata are excluded.

Run `python3 verify_package.py` after extracting to verify all exported file hashes. For original manifest signatures and included signed output hashes, install `cryptography` and run `python3 verify_package.py --signatures`. This is **not full pandax verify** because vendor inputs are omitted. Original full verification responses are preserved. Demo signatures demonstrate integrity, not external certification or factual completeness.

Automatic Annex VII / Declaration PDFs inside bundles are unreviewed PoC outputs, not the independent answer key or an approved compliance declaration. Raw evidence retains historical local paths/URLs for integrity; use the portable index and case links to navigate offline. Public advisory links need internet access. The package checksum detects file changes; it is not an independent attestation.
