# Example web application 1.0.0 / SBOM

1 hits; 0 misses; 0 correct absences; 2 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2020-11023 | find | FOUND | HIT |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
