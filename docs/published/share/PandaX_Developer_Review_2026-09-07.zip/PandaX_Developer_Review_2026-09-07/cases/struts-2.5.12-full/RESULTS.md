# Struts 2.5.12 / full libraries

3 hits; 0 misses; 0 correct absences; 160 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2018-11776 | find | FOUND | HIT |
| CVE-2023-50164 | find | FOUND | HIT |
| CVE-2017-9805 | find | FOUND | HIT |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
