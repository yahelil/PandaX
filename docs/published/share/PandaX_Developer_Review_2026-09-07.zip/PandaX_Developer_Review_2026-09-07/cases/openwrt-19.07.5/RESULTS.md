# OpenWrt 19.07.5

2 hits; 0 misses; 6 correct absences; 2 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2020-7248 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2020-25681 | excluded | NOT_FOUND | CORRECT ABSENCE |
| CVE-2020-25682 | excluded | NOT_FOUND | CORRECT ABSENCE |
| CVE-2020-25683 | excluded | NOT_FOUND | CORRECT ABSENCE |
| CVE-2020-25684 | find | FOUND | HIT |
| CVE-2020-25685 | excluded | NOT_FOUND | CORRECT ABSENCE |
| CVE-2020-25686 | find | FOUND | HIT |
| CVE-2020-25687 | excluded | NOT_FOUND | CORRECT ABSENCE |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
