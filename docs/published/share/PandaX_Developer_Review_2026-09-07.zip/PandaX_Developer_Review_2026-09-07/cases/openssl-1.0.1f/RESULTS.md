# OpenSSL 1.0.1f / s_server

1 hits; 2 misses; 0 correct absences; 1 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2014-0160 | find | FOUND | HIT |
| CVE-2014-0224 | find | NOT_FOUND | MISS |
| CVE-2014-0195 | find | NOT_FOUND | MISS |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
