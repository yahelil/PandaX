Actis Collector (Windows x64)
=============================

Generate local CycloneDX SBOMs or collect signed evidence for Actis CRA Compliance.

Quick start:
1. Open PowerShell in this directory.
2. Run:
   .\actis-collector.exe sbom "C:\path\to\your\project" --output ".\bom.cdx.json"

This scans your files locally with the embedded Syft engine and exports a valid
CycloneDX 1.6 SBOM document. No source code is uploaded to the cloud.

Upload the generated om.cdx.json into the Actis dashboard wizard.
