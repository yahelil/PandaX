"""Verify exported file hashes. Optional --signatures requires cryptography.
This is a partial output export; omitted input/extracted trees are not verified.
"""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/'SHA256SUMS.json').read_text())
for name,want in m.items():
 p=root/name
 if not p.is_relative_to(root) or not p.is_file():raise SystemExit('Missing: '+name)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=want:raise SystemExit('Changed: '+name)
print(f'PASS: {len(m)} exported files match SHA-256 manifest.')
if '--signatures' in sys.argv:
 from cryptography.hazmat.primitives.serialization import load_pem_public_key
 for p in sorted((root/'evidence/bundles').iterdir()):
  manifest=json.loads((p/'manifest.json').read_text())
  canonical=json.dumps(manifest,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
  load_pem_public_key((p/'pubkey.pem').read_bytes()).verify(bytes.fromhex((p/'manifest.sig').read_text().strip()),canonical)
  for item in manifest['files']:
   f=p/item['path']
   if f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('Signed file changed: '+str(f))
 print('PASS: all original manifest signatures and included signed file hashes verify.')
print('Vendor input/extracted trees are intentionally omitted. This is not full pandax verify. Local demo signatures prove integrity, not independent certification.')
