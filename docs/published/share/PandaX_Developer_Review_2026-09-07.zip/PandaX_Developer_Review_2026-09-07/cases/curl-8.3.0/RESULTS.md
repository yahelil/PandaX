# curl / libcurl 8.3.0

1 hits; 2 misses; 1 correct absences; 1 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2023-38545 | find | FOUND | HIT |
| CVE-2023-38546 | find | NOT_FOUND | MISS |
| CVE-2023-46218 | find | NOT_FOUND | MISS |
| CVE-2023-38039 | fixed | NOT_FOUND | CORRECT ABSENCE |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
