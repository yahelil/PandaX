# OpenSSL 1.0.1g / s_server

0 hits; 2 misses; 1 correct absences; 0 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2014-0160 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2014-0224 | find | NOT_FOUND | MISS |
| CVE-2014-0195 | find | NOT_FOUND | MISS |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
