# Reproduce the run

Clone https://github.com/yahelil/PandaX and check out d7f78903473a0efb3ed3830b4b5b2e470d7ae8ad. Follow that revision's README to bootstrap the dashboard. The exact tested source and fixtures are also included here. Copy tools/evaluate_reference.py into the checkout tools/ directory, reference/expected-results-baseline.json to docs/, and the independent PDF to output/pdf/. The evaluator uses repository-relative paths; run it from that checkout, not directly from this ZIP.

Run `python tools/evaluate_reference.py --base-url http://127.0.0.1:8000`. Exit 1 means named checks or executions failed; read the generated report. This observed run exited 1 for seven missing findings. Public feeds can change; the ZIP preserves this run and later diagnostic responses.

The root-cause probe expects output/validation/pandax-reference-comparison.json and the saved API evidence at the report's evidence_directory. Restore those from this ZIP before rerunning the probe. The package builder additionally requires all original local out/ bundles.
