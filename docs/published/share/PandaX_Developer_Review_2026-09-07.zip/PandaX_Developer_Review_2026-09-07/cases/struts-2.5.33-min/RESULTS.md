# Struts 2.5.33 / min libraries

0 hits; 0 misses; 3 correct absences; 9 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2018-11776 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2023-50164 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2017-9805 | excluded | NOT_FOUND | CORRECT ABSENCE |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
