# SmartHub 2.3.1 / zip

10 hits; 0 misses; 0 correct absences; 102 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2020-11023 | find | FOUND | HIT |
| CVE-2020-8203 | find | FOUND | HIT |
| CVE-2021-44906 | find | FOUND | HIT |
| CVE-2022-24771 | find | FOUND | HIT |
| CVE-2021-25293 | find | FOUND | HIT |
| CVE-2018-18074 | find | FOUND | HIT |
| CVE-2019-11324 | find | FOUND | HIT |
| CVE-2020-14343 | find | FOUND | HIT |
| CVE-2019-10906 | find | FOUND | HIT |
| CVE-2021-44228 | find | FOUND | HIT |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
