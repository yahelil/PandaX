# Struts 2.5.12 / min libraries

2 hits; 0 misses; 1 correct absences; 22 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2018-11776 | find | FOUND | HIT |
| CVE-2023-50164 | find | FOUND | HIT |
| CVE-2017-9805 | excluded | NOT_FOUND | CORRECT ABSENCE |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
