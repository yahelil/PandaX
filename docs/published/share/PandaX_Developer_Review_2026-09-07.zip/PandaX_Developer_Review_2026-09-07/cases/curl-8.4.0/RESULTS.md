# curl / libcurl 8.4.0

0 hits; 1 misses; 3 correct absences; 0 reported component/CVE rows.

| CVE | Expected | Observed | Result |
|---|---|---|---|
| CVE-2023-38545 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2023-38546 | fixed | NOT_FOUND | CORRECT ABSENCE |
| CVE-2023-46218 | find | NOT_FOUND | MISS |
| CVE-2023-38039 | fixed | NOT_FOUND | CORRECT ABSENCE |

See index.html for applicability/source links, all-findings.csv for every reported row, and result.json for complete comparison details.
